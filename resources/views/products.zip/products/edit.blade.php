<!DOCTYPE html>
<html>
<head>
    <title>Modifier un Produit</title>
</head>
<body>

<h1>Modifier le Produit</h1>

<form action="{{ route('products.update', $product->id) }}" method="POST">
    @csrf
    @method('PUT')

    <label for="name">Nom :</label><br>
    <input type="text" name="name" id="name" value="{{ old('name', $product->name) }}"><br>
    @error('name')
        <p style="color: red;">{{ $message }}</p>
    @enderror
    <br>

    <label for="price">Prix :</label><br>
    <input type="number" step="0.01" name="price" id="price" value="{{ old('price', $product->price) }}"><br>
    @error('price')
        <p style="color: red;">{{ $message }}</p>
    @enderror
    <br>

    <button type="submit">Mettre à jour</button>
</form>

<br>
<a href="{{ route('products.index') }}">Retour à la liste</a>

</body>
</html>
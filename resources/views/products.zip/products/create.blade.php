<!DOCTYPE html>
<html>
<head>
    <title>Ajouter un Produit</title>
</head>
<body>

<h1>Ajouter un Produit</h1>

<form action="{{ route('products.store') }}" method="POST">
    @csrf

    <label for="name">Nom :</label><br>
    <input type="text" name="name" id="name" value="{{ old('name') }}"><br>
    @error('name')
        <p style="color: red;">{{ $message }}</p>
    @enderror
    <br>

    <label for="price">Prix :</label><br>
    <input type="number" step="0.01" name="price" id="price" value="{{ old('price') }}"><br>
    @error('price')
        <p style="color: red;">{{ $message }}</p>
    @enderror
    <br>

    <button type="submit">Enregistrer</button>
</form>

<br>
<a href="{{ route('products.index') }}">Retour à la liste</a>

</body>
</html>
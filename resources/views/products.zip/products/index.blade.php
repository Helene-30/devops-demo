<!DOCTYPE html>
<html>
<head>
    <title>Liste des Produits</title>
</head>
<body>

<h1>Liste des Produits</h1>

<a href="{{ route('products.create') }}">Ajouter un produit</a>
<a href="{{ route('products.pdf') }}" style="margin-left: 20px;">Télécharger en PDF</a>
<br><br>

@if(session('success'))
    <p style="color: green;">{{ session('success') }}</p>
@endif

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Prix</th>
        <th>Actions</th>
    </tr>

    @foreach($products as $product)
    <tr>
        <td>{{ $product->id }}</td>
        <td>{{ $product->name }}</td>
        <td>{{ number_format($product->price, 2, ',', ' ') }} FCFA</td>
        <td>
            <a href="{{ route('products.show', $product->id) }}">Voir</a>
            |
            <a href="{{ route('products.edit', $product->id) }}">Modifier</a>
            |
            <form action="{{ route('products.destroy', $product->id) }}" 
                  method="POST"
                  style="display:inline;"
                  onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?');">
                @csrf
                @method('DELETE')
                <button type="submit" style="cursor: pointer;">Supprimer</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

</body>
</html>
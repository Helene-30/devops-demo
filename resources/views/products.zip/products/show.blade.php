<!DOCTYPE html>
<html>
<head>
    <title>Détails du Produit</title>
</head>
<body>

<h1>Détails du Produit</h1>

<p><strong>ID :</strong> {{ $product->id }}</p>
<p><strong>Nom :</strong> {{ $product->name }}</p>
<p><strong>Prix :</strong> {{ number_format($product->price, 2, ',', ' ') }} FCFA</p>
<p>
    <strong>Créé le :</strong> 
    {{ $product->created_at->format('d/m/Y à H:i') }}
</p>

<br>
<a href="{{ route('products.index') }}">Retour à la liste</a>

</body>
</html>